-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 30 mai 2024 à 18:18
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `BD_topcas`
--

-- --------------------------------------------------------

--
-- Structure de la table `cas`
--

CREATE TABLE `cas` (
  `id` int(11) NOT NULL,
  `nomUtilisateur` varchar(40) NOT NULL,
  `messages` varchar(500) DEFAULT NULL,
  `temps` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `cas`
--

INSERT INTO `cas` (`id`, `nomUtilisateur`, `messages`, `temps`) VALUES
(67, 'Gedeon', 'hello world', '2024-05-30 11:17:33'),
(68, 'Mariam', 'stp', '2024-05-30 11:35:18'),
(69, 'Mariam', 'stp', '2024-05-30 11:35:20'),
(70, 'Mariam', 'stp', '2024-05-30 11:35:22'),
(71, 'Mariam', 'stp', '2024-05-30 11:35:22'),
(72, 'Mariam', 'stp', '2024-05-30 11:35:25'),
(73, 'Mariam', 'stp', '2024-05-30 11:35:25'),
(74, 'Mariam', 'stp', '2024-05-30 11:35:26'),
(75, 'Mariam', 'slt', '2024-05-30 11:35:34'),
(76, 'Mariam', 'slt', '2024-05-30 11:35:34');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cas`
--
ALTER TABLE `cas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cas`
--
ALTER TABLE `cas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
